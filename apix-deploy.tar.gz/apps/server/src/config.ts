import "dotenv/config";

export const config = {
  NODE_ENV: process.env.NODE_ENV ?? "development",
  SERVER_PORT: parseInt(process.env.SERVER_PORT ?? "3001", 10),
  SERVER_HOST: process.env.SERVER_HOST ?? "0.0.0.0",

  DATABASE_URL: process.env.DATABASE_URL ?? "postgresql://apix:apix_password@localhost:5432/apix",

  JWT_SECRET: process.env.JWT_SECRET ?? "dev-secret",
  JWT_REFRESH_SECRET: process.env.JWT_REFRESH_SECRET ?? "dev-refresh-secret",

  MINIO_ENDPOINT: process.env.MINIO_ENDPOINT ?? "localhost",
  MINIO_PORT: parseInt(process.env.MINIO_PORT ?? "9000", 10),
  MINIO_ACCESS_KEY: process.env.MINIO_ACCESS_KEY ?? "minioadmin",
  MINIO_SECRET_KEY: process.env.MINIO_SECRET_KEY ?? "minioadmin",
  MINIO_BUCKET: process.env.MINIO_BUCKET ?? "apix-photos",
  MINIO_USE_SSL: process.env.MINIO_USE_SSL === "true",
} as const;