CREATE TABLE IF NOT EXISTS "machine_types" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" varchar(100) NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "machine_type_toys" (
	"machine_type_id" integer NOT NULL,
	"toy_id" integer NOT NULL,
	CONSTRAINT machine_type_toys_machine_type_id_toy_id PRIMARY KEY("machine_type_id","toy_id")
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "toy_price_history" (
	"id" serial PRIMARY KEY NOT NULL,
	"toy_id" integer NOT NULL,
	"price" numeric(10, 2) NOT NULL,
	"valid_from" timestamp with time zone DEFAULT now() NOT NULL,
	"created_by" integer
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "toys" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" varchar(100) NOT NULL,
	"price" numeric(10, 2) NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "refresh_tokens" (
	"id" serial PRIMARY KEY NOT NULL,
	"staff_id" integer NOT NULL,
	"token_hash" varchar(255) NOT NULL,
	"expires_at" timestamp with time zone NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"revoked_at" timestamp with time zone,
	CONSTRAINT "refresh_tokens_token_hash_unique" UNIQUE("token_hash")
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "staff" (
	"id" serial PRIMARY KEY NOT NULL,
	"email" varchar(255) NOT NULL,
	"full_name" varchar(255) NOT NULL,
	"password" varchar(255) NOT NULL,
	"role" varchar(20) NOT NULL,
	"city_id" integer,
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "staff_email_unique" UNIQUE("email")
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "locations" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" varchar(255) NOT NULL,
	"parent_id" integer,
	"node_type" varchar(50),
	"min_service_days" integer,
	"max_service_days" integer,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "route_locations" (
	"route_id" integer NOT NULL,
	"location_id" integer NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL,
	CONSTRAINT route_locations_route_id_location_id PRIMARY KEY("route_id","location_id")
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "routes" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" varchar(255) NOT NULL,
	"description" text,
	"min_service_days" integer,
	"max_service_days" integer,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "machine_routes" (
	"machine_number" integer NOT NULL,
	"route_id" integer NOT NULL,
	CONSTRAINT machine_routes_machine_number_route_id PRIMARY KEY("machine_number","route_id")
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "machine_technicians" (
	"machine_number" integer NOT NULL,
	"staff_id" integer NOT NULL,
	CONSTRAINT machine_technicians_machine_number_staff_id PRIMARY KEY("machine_number","staff_id")
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "machine_toys" (
	"machine_number" integer NOT NULL,
	"toy_id" integer NOT NULL,
	"action" varchar(10) NOT NULL,
	CONSTRAINT machine_toys_machine_number_toy_id PRIMARY KEY("machine_number","toy_id")
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "machines" (
	"number" integer PRIMARY KEY NOT NULL,
	"location_id" integer NOT NULL,
	"type_id" integer NOT NULL,
	"status" varchar(20) DEFAULT 'active' NOT NULL,
	"price_per_game" numeric(10, 2) NOT NULL,
	"has_prize_counter" boolean DEFAULT true NOT NULL,
	"min_service_days" integer,
	"max_service_days" integer,
	"deleted_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "machine_placements" (
	"id" serial PRIMARY KEY NOT NULL,
	"machine_number" integer NOT NULL,
	"started_at" timestamp with time zone DEFAULT now() NOT NULL,
	"ended_at" timestamp with time zone,
	"game_counter_initial" integer DEFAULT 0 NOT NULL,
	"prize_counter_initial" integer DEFAULT 0 NOT NULL,
	"created_by" integer,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "service" (
	"id" serial PRIMARY KEY NOT NULL,
	"placement_id" integer NOT NULL,
	"machine_number" integer,
	"staff_id" integer NOT NULL,
	"service_date" date NOT NULL,
	"service_time" time NOT NULL,
	"game_counter" integer NOT NULL,
	"prize_counter" integer,
	"test_games" integer DEFAULT 0 NOT NULL,
	"is_operational" boolean DEFAULT true NOT NULL,
	"comment" text,
	"price_per_game" numeric(10, 2) NOT NULL,
	"before_service_id" integer,
	"period_days" integer,
	"new_games" integer,
	"new_prizes" integer,
	"revenue" numeric(12, 2),
	"cost_of_toys" numeric(12, 2),
	"roi" numeric(8, 4),
	"photo_counter_url" text,
	"photo_before_url" text,
	"photo_after_url" text,
	"synced_at" timestamp with time zone DEFAULT now() NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "toy_distribution" (
	"id" serial PRIMARY KEY NOT NULL,
	"service_id" integer NOT NULL,
	"toy_id" integer NOT NULL,
	"quantity" integer DEFAULT 0 NOT NULL,
	"price_snapshot" numeric(10, 2) NOT NULL,
	"total_cost" numeric(10, 2) NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "audit_log" (
	"id" bigserial PRIMARY KEY NOT NULL,
	"table_name" varchar(100) NOT NULL,
	"record_id" text NOT NULL,
	"action" varchar(10) NOT NULL,
	"user_id" integer,
	"changed_at" timestamp with time zone DEFAULT now() NOT NULL,
	"old_data" jsonb,
	"new_data" jsonb
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "audit_log_archive" (
	"id" bigserial PRIMARY KEY NOT NULL,
	"table_name" varchar(100) NOT NULL,
	"record_id" text NOT NULL,
	"action" varchar(10) NOT NULL,
	"user_id" integer,
	"changed_at" timestamp with time zone DEFAULT now() NOT NULL,
	"old_data" jsonb,
	"new_data" jsonb
);
--> statement-breakpoint
CREATE UNIQUE INDEX IF NOT EXISTS "idx_service_placement_date" ON "service" ("placement_id","service_date");--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "machine_type_toys" ADD CONSTRAINT "machine_type_toys_machine_type_id_machine_types_id_fk" FOREIGN KEY ("machine_type_id") REFERENCES "machine_types"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "machine_type_toys" ADD CONSTRAINT "machine_type_toys_toy_id_toys_id_fk" FOREIGN KEY ("toy_id") REFERENCES "toys"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "toy_price_history" ADD CONSTRAINT "toy_price_history_toy_id_toys_id_fk" FOREIGN KEY ("toy_id") REFERENCES "toys"("id") ON DELETE no action ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "toy_price_history" ADD CONSTRAINT "toy_price_history_created_by_staff_id_fk" FOREIGN KEY ("created_by") REFERENCES "staff"("id") ON DELETE no action ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "refresh_tokens" ADD CONSTRAINT "refresh_tokens_staff_id_staff_id_fk" FOREIGN KEY ("staff_id") REFERENCES "staff"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "staff" ADD CONSTRAINT "staff_city_id_locations_id_fk" FOREIGN KEY ("city_id") REFERENCES "locations"("id") ON DELETE no action ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "locations" ADD CONSTRAINT "locations_parent_id_locations_id_fk" FOREIGN KEY ("parent_id") REFERENCES "locations"("id") ON DELETE no action ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "route_locations" ADD CONSTRAINT "route_locations_route_id_routes_id_fk" FOREIGN KEY ("route_id") REFERENCES "routes"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "route_locations" ADD CONSTRAINT "route_locations_location_id_locations_id_fk" FOREIGN KEY ("location_id") REFERENCES "locations"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "machine_routes" ADD CONSTRAINT "machine_routes_machine_number_machines_number_fk" FOREIGN KEY ("machine_number") REFERENCES "machines"("number") ON DELETE cascade ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "machine_routes" ADD CONSTRAINT "machine_routes_route_id_routes_id_fk" FOREIGN KEY ("route_id") REFERENCES "routes"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "machine_technicians" ADD CONSTRAINT "machine_technicians_machine_number_machines_number_fk" FOREIGN KEY ("machine_number") REFERENCES "machines"("number") ON DELETE cascade ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "machine_technicians" ADD CONSTRAINT "machine_technicians_staff_id_staff_id_fk" FOREIGN KEY ("staff_id") REFERENCES "staff"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "machine_toys" ADD CONSTRAINT "machine_toys_machine_number_machines_number_fk" FOREIGN KEY ("machine_number") REFERENCES "machines"("number") ON DELETE cascade ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "machine_toys" ADD CONSTRAINT "machine_toys_toy_id_toys_id_fk" FOREIGN KEY ("toy_id") REFERENCES "toys"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "machines" ADD CONSTRAINT "machines_location_id_locations_id_fk" FOREIGN KEY ("location_id") REFERENCES "locations"("id") ON DELETE no action ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "machines" ADD CONSTRAINT "machines_type_id_machine_types_id_fk" FOREIGN KEY ("type_id") REFERENCES "machine_types"("id") ON DELETE no action ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "machine_placements" ADD CONSTRAINT "machine_placements_machine_number_machines_number_fk" FOREIGN KEY ("machine_number") REFERENCES "machines"("number") ON DELETE no action ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "machine_placements" ADD CONSTRAINT "machine_placements_created_by_staff_id_fk" FOREIGN KEY ("created_by") REFERENCES "staff"("id") ON DELETE no action ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "service" ADD CONSTRAINT "service_placement_id_machine_placements_id_fk" FOREIGN KEY ("placement_id") REFERENCES "machine_placements"("id") ON DELETE no action ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "service" ADD CONSTRAINT "service_machine_number_machines_number_fk" FOREIGN KEY ("machine_number") REFERENCES "machines"("number") ON DELETE no action ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "service" ADD CONSTRAINT "service_staff_id_staff_id_fk" FOREIGN KEY ("staff_id") REFERENCES "staff"("id") ON DELETE no action ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "service" ADD CONSTRAINT "service_before_service_id_service_id_fk" FOREIGN KEY ("before_service_id") REFERENCES "service"("id") ON DELETE no action ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "toy_distribution" ADD CONSTRAINT "toy_distribution_service_id_service_id_fk" FOREIGN KEY ("service_id") REFERENCES "service"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "toy_distribution" ADD CONSTRAINT "toy_distribution_toy_id_toys_id_fk" FOREIGN KEY ("toy_id") REFERENCES "toys"("id") ON DELETE no action ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "audit_log" ADD CONSTRAINT "audit_log_user_id_staff_id_fk" FOREIGN KEY ("user_id") REFERENCES "staff"("id") ON DELETE no action ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "audit_log_archive" ADD CONSTRAINT "audit_log_archive_user_id_staff_id_fk" FOREIGN KEY ("user_id") REFERENCES "staff"("id") ON DELETE no action ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
